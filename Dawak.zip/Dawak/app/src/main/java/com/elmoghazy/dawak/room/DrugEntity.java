package com.elmoghazy.dawak.room;

public class DrugEntity {
}
